<!-- page content -->
<div class="col-md-12">
  <div class="col-middle">
    <div class="text-center text-center">
      <h1 class="error-number">403</h1>
      <h2>Akses Dilarang</h2>
      <p>Otentikasi penuh diperlukan untuk mengakses sumber ini.
        <br><br>
        <a class="btn btn-default btn-sm btn-warning" href="<?= base_url('auth'); ?>">KEMBALI!!</a>
      </p>
    </div>
  </div>
</div>
<!-- /page content -->